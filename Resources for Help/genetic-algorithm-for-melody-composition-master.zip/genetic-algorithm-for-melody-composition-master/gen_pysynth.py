from constants import *

def toPsNote(chromosone):
    # assert isinstance(note, basestring)
    # assert len(node) == 1
    # assert note in NOTES
    return (note, DURATION)

